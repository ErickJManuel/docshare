Copyright (c) 2005, Persony, Inc. All rights reserved.

Release history
1.0.14 4/21/05 Initial release

Persony's screen capture module is based on the Windows source code of TightVNC 1.3dev3 (http://www.tightvnc.com), which is distributed under the GNU GPL license. Per the GPL license, Persony is re-distributing a modified version of the TiightVNC source code under the same license. A copy of the GNU GPL license is included with the release.

In an effort to create a TightVNC based recorder for recording a vnc file that allows random access playback and editing, I have inserted "key frames" to a Tight encoded stream by requesting full framebuffer updates from the TightVNC server at some time interval. The method works fine for other encoders, such as Raw. It doesn't work for Tight encoded files. The Tight encoder uses zlib as one of the encoding formats but only initializes the zlib streams in the beginning. The zlib streams are never reset even in a full framebuffer update request. As a result, the "key frames" are still dependent on the previous frames and the decoder can't simply jump to the key frames without decoding the previous frames, which makes random access or truncating of recorded files difficult.

The Tight encoding has provision for resetting the zlib streams (as documented in rfbproto.h) but I can't find any implementation for it in the winvnc server source code. I have added the implementation as described in the attached file. Basically, I added a "ResetEncoding" method to the Encoder class and it is called when a full framebuffer update request is received from a vnc client. I have only implemented it for the Tight encoder but you may need to add implementation for any zlib based encoder.

Other changes mainly involve setting various encoding options through command line arguments.

The "modified" folder contains modified files of the original TightVNC source code. The complete TightVNC 1.3dev3 source code is in the "vnc_winsrc" folder.

Eric Chen
Persony, Inc.
echen@persony.com
