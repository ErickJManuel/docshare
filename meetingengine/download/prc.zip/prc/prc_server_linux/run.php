<?php
// Copyright 2006, Persony, Inc. All rights reserved. www.persony.com

	function ErrorExit($msg) {
		die("ERROR ".$msg);
	}
	if (phpversion() < "4.1.0") {
		$GET_VARS		= $HTTP_GET_VARS;
	} else {
		$GET_VARS		= $_GET;
	}
		
	$scriptPassFile="run.pas";	
	$fp=@fopen($scriptPassFile, "r");
	if ($fp) {
		$scriptPass=fread($fp, filesize($scriptPassFile));
		fclose($fp);
		
		$pass='';
		if (isset($GET_VARS['pas']))
			$pass=$GET_VARS['pas'];
		if ($pass!=$scriptPass)
			ErrorExit("Incorrect password");
	}
	
	$startPort=5500;
	$endPort=5999;
	$portFile="run.port";
	$fp=@fopen($portFile, "r");
	if ($fp) {
		$content=fread($fp, filesize($portFile));
		fclose($fp);
		list($startPort, $endPort) = sscanf($content,"%d %d");
		if ($startPort<=0 || $endPort<$startPort+1)
			ErrorExit("Invalid port ".$startPort." ".$endPort);
	}	

//	$dir=dirname(__FILE__);
	$vrefExeFile='';
	if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
//		$vrefExeFile="$dir\\vncreflector.exe";
		$vrefExeFile=".\\vncreflector.exe";
	} else { 
//		$vrefExeFile="$dir/vncreflector";
		$vrefExeFile="./vncreflector";
	}
	
	if (!file_exists($vrefExeFile))
		ErrorExit('Missing file '.$vrefExeFile);
		
	$vncPass=rand(1000, 32768);
	
	$pidPrefix="pid";
	$pidFile='';
	$clientPort=$startPort+1;
	
	// Each VNC connection requires two ports: one for the vnc server and one for a vnc client
	// The vnc server port is a port starts on $startPort
	// The vnc client port is $startPort+1			
	// Find an available port to listen  by checking if the pid file exists
	// The pid file name is pid.xxxx, where xxxx is the client port number to listen on
	// The pid file is created when the reflector starts and deleted when it terminates
	for ( ; $clientPort<=$endPort; $clientPort+=2) {
		$pidFile=$pidPrefix.".".$clientPort;
		if (file_exists($pidFile))
			continue;
		else
			break;
	}
	
	if ($clientPort>$endPort) {
		ErrorExit("Couldn't find an available port");
	}
	
	$pasFile=$clientPort.".pas";
	$infFile=$clientPort.".inf";
	$conFile=$clientPort.".con";
	$errFile=$clientPort.".err";
	$serverPort=$clientPort-1;
	
	$fp=@fopen($pasFile, "wb");
	if ($fp) {
		fwrite($fp, $vncPass);
		fclose($fp);
	} else {
		ErrorExit("Couldn't create file ".$pasFile);
	}
	$fp=@fopen($infFile, "wb");
	if ($fp) {
		fwrite($fp, "*:".$serverPort);
		fclose($fp);
	} else {
		ErrorExit("Couldn't create file ".$infFile);	
	}
	$cmd="$vrefExeFile -i $pidPrefix -l $clientPort -a $conFile -p $pasFile -t -q $infFile";
	
//	$run=`$cmd`;
	$run=exec($cmd, $arr, $err);
	
	// wait for the command to execute
	// if there is an error, $errFile will be created
	sleep(1);
	if (!@unlink($pasFile))
		ErrorExit("Couldn't delete file ".$pasFile);	
	
	if (!@unlink($infFile))
		ErrorExit("Couldn't delete file ".$infFile);	
	
	if ($err!=0)
		ErrorExit("Couldn't execute command.");	

	if (file_exists($errFile)) {
		echo "ERROR \n";
		readfile($errFile);
	} else if (!file_exists($pidFile)) {
		ErrorExit("Command failed to start. See log file for errors.");
	} else {
		echo "OK ".$serverPort." ".$clientPort." ".$vncPass;
	}
?>