<?php
	if (phpversion() < "4.1.0") {
		$GET_VARS		= $HTTP_GET_VARS;
	} else {
		$GET_VARS		= $_GET;
	}	
	$host='';
	if (isset($GET_VARS['host']))
		$host=$GET_VARS['host'];
	$port='';
	if (isset($GET_VARS['port']))
		$port=$GET_VARS['port'];
	$pwd='';
	if (isset($GET_VARS['pwd']))
		$pwd=$GET_VARS['pwd'];
	$width=800;
	if (isset($GET_VARS['width']))
		$width=$GET_VARS['width'];
	$height=600;
	if (isset($GET_VARS['height']))
		$height=$GET_VARS['height'];
	$height+=24; // add the height of the menu bar

echo <<<END_OF_FILE
<HTML>
<HEAD>
<TITLE>Remote desktop $host </TITLE>
</HEAD>
<BODY topmargin=0 leftmargin=0>
<APPLET CODE=VncViewer.class ARCHIVE=VncViewer.jar WIDTH=$width HEIGHT=$height>
<PARAM NAME="PORT" VALUE=$port>
<PARAM NAME="PASSWORD" VALUE=$pwd>
</APPLET><BR>
</BODY>
</HTML>
END_OF_FILE;
?>