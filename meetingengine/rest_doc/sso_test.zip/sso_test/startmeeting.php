<?php
/**
 * @author      Persony, Inc. <info@persony.com>
 * @copyright   Copyright 2010 Persony, Inc.
 * @version     2.0
 * 
 * The example shows how to sign in a host user, start a meeting and then
 * redirect the host to the meeting viewer page.
 * The example uses "allow.php" for SSO authentication.
 * 
 */

// Meeting site url
$siteUrl="http://my_site.com/meeting/";

// Replace with your api url and brand id with those from the Administration/API page
$apiUrl="http://persony_server/wc2/rest/";
$apiKey='xxxx';
$brand='xxxx';

// SSO callback url. Replace the host name with yours.
// You must add the host name to the Admin/API/SSO Host Name field
$storageServerUrl="http://my_site.com/sso_test/allow.php";

// User and meeting information
$login="me@comany.com";	// Login name of the host. If the user does not exist, it will be created.
$password="";			// Login password of the host. This is only needed if the user does not exist. A new user will be created with the password.
$meetingId="1111111";		// ID of the meeting to start. Find the meeting id from the member's My Meetings page, or use "meetings" API object to get all meetings of the user.

// Check meeting status
$apiObj="meeting";	// API object

$request="brand=$brand&id=$meetingId";
$signature=md5($request.$apiKey);	// compute the signature for the request
$request.="&signature=".$signature;

$apiObjUrl=$apiUrl.$apiObj."/"; // trailing slash is required

// Send request with HTTP GET
$resp=file_get_contents($apiObjUrl."?".$request);
if (!$resp)
	die("Couldn't get a response from ".$apiObjUrl);

$xml = simplexml_load_string($resp);
// Make sure we get an xml response
if (!$xml)
	die("Invalid response ".$resp);

// Check for error	
if ($xml->error)
	die($xml->error->message);

// Make sure the meeting exists	
if (!$xml->meeting || !$xml->meeting->status)
	die("Couldn't get a meeting from id ".$meetingId);

// if meeting is stopped, start it
if ($xml->meeting->status=='STOP') {
	
	// Set meeting status
	$method='PUT';	// Use PUT to change the meeting status
	$status="START"; // Set the meeting status
	
	$request="brand=$brand&method=$method&id=$meetingId&status=$status";
	$signature=md5($request.$apiKey);	// compute the signature for the request
	$request.="&signature=".$signature;
	
	$apiObjUrl=$apiUrl.$apiObj."/"; // trailing slash is required
	
	// Send request with HTTP POST
	$resp=http_post_request($apiObjUrl, $request);
	if (!$resp)
		die("Couldn't get a response from ".$apiObjUrl);
	
	$xml = simplexml_load_string($resp);
	
	// Check if we get a valid response and the meeting is started
	if (!$xml || !$xml->meeting || $xml->meeting->status!='START')
		die("Couldn't start the meeting");		

} else if ($xml->meeting->status=="REC") {
	die("Attemp to start a recorded meeting");
}

// find the host_url from the meeting record
if (!$xml->meeting->host_url)
	die("Host url not found in meeting record.");

// construct an SSO url to sign in the user and then redirect to the host url
// All parameters should be url encoded
// StorageSessionId can be any value that is meaningful to your application
$ssoUrl=$siteUrl.
	"?StorageServerUrl=".rawurlencode($storageServerUrl).
	"&StorageUserName=".rawurlencode($login).
	"&StorageSessionId=1";

// If password is provided, pass it in
if ($password!='')
	$ssoUrl.="&StoragePassword=".rawurlencode($password);
	
// Redirect to the host url
$ssoUrl.="&PSRedirectUrl=".rawurlencode($xml->meeting->host_url);

// Now call the url to sign in the user and then redirect to the meeting viewer
header("Location: $ssoUrl");
exit();

// curl must be enabled for this function to work
function http_post_request($url, $data){
	
	if (!function_exists('curl_init'))
		die("Curl not enabled.");
	
	$ch = curl_init($url);
	
	// disable ssl site certificate verification
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	
	curl_setopt($ch, CURLOPT_TIMEOUT, 15);
	// return the response data
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);			
	
	$result = curl_exec($ch);
	curl_close($ch);
	return $result;
}

?>